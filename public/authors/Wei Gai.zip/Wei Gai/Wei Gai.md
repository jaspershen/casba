---
authors:
- Wei Gai
education:
  courses:
  - course: PhD
    institution: Texas A&M University
    year: 2018-present
  - course: Master
    institution: 中国科学院上海药物研究所
    year: 2012-2016
email: "gwsimm@hotmail.com"
interests:
- Biochemistry
- Biophysics
- pharmacology
- Computational biology
name: 盖伟
organizations:
- name: Texas A&M University
role: 分会长/博士

---

