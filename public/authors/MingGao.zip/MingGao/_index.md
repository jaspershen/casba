---
authors:
- MingGao
bio:神经药理
education:
  courses:
  - course: PhD
    institution: 中国科学院上海药物研究所
    year: 2003-2007
  - course: 
    institution: 
    year: 
email: 
interests:
- 神经科学
- 
- 
- 
name: 高明 博士
organizations:
- name: Barrow Neurological Institute
  url: "https://www.barrowneur.org/"
role: 分会长
social:
social:
- icon: 
  icon_pack: 
  link: 
- icon: 
  icon_pack: 
  link: 
- icon: 
  icon_pack: 
  link: 
- icon: 
  icon_pack: 
  link: 
superuser: true
user_groups:
- Vice_president

---

工作方向属于基础神经生物学研究，采用电生理技术及行为学实验，研究成瘾药物对中脑多巴胺系统的的作用机制以及相关的神经精神疾病。